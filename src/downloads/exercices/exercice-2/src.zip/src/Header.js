import React from 'react';
import './App.css';

export default function Header() {
  return (
    <div>
      <h3> My first JSX </h3>
        <div>
          <p> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed maximus orci quis orci venenatis lacinia. Maecenas non velit in velit vehicula consectetur. Sed at leo finibus, molestie ex ac, convallis mauris. Aliquam consequat elit sed ligula vestibulum tristique. Phasellus finibus ligula id massa dignissim congue. Aliquam interdum sollicitudin tristique. Nulla at est cursus velit luctus tincidunt. Fusce vel lacus sem. Curabitur faucibus, leo eget fermentum maximus, turpis felis sagittis arcu, ut aliquet est enim vitae nulla. Nunc consequat posuere cursus. Cras faucibus sit amet leo faucibus placerat. Suspendisse elementum sit amet erat in cursus. Integer et neque et tortor varius finibus. Donec vitae dignissim eros, sed feugiat urna.</p>
          <button> Click </button>
        </div>
    </div>
  );
}
