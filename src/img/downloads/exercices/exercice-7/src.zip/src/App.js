import React from 'react';
import './App.css';
import Header from "./Header";
import axios from 'axios';
import Student from './Student';

class App extends React.Component {
  constructor(){
    super();
    this.state = {
      name: "john",
      students: null
    }
    this.changeName = this.changeName.bind(this);
  }

  componentDidMount() {
    axios.get('https://codycollicott.github.io/yearbook/Data/students.json')
    .then(response => {
      this.setState({
        ...this.state,
        students: response.data
      })
    })
    .catch(error => {
      console.log("an error occured")
      console.log(error);
    })
  }

  changeName() {
    this.setState({
      name: "bob"
    })
  }

  render() {
    
    const { students } = this.state;
    console.log(students);
    return (
      <div className="App">
        <Header
          name={this.state.name}
          title="My first Prop Passed" 
          buttonTitle="Button label"
        />
        <h3 onClick={this.changeName}> Change Name </h3>
        {students && students.map(student => {
          return <Student info={student} />
        })}
      </div>
    );
  }
}

export default App;
