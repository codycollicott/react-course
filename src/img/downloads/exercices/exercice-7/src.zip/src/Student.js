import React from 'react';
import './App.css';

export default function Student(props) {
  console.log(props);
  return (
    <div>
      <h3> {props.info.title} </h3>
    </div>
  );
}
