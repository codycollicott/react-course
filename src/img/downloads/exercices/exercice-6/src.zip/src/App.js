import React from 'react';
import './App.css';
import Header from "./Header";

class App extends React.Component {
  constructor(){
    super();
    this.state = {
      name: "john"
    }
    this.changeName = this.changeName.bind(this);
  }

  changeName() {
    this.setState({
      name: "bob"
    })
  }

  render() {
    return (
      <div className="App">
        <Header
          name={this.state.name}
          title="My first Prop Passed" 
          buttonTitle="Button label"
        />
        <h3 onClick={this.changeName}> Change Name </h3>
      </div>
    );
  }
}

export default App;
